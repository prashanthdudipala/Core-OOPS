/**
 * Created by prashanth on 10/12/17.
 * Imagine that the sorted array has been rotated at unkonwn point and we are supposed to search the element in the array
 * after it has been rotated.
 * Input would be regular array {1,2,3,4,5,6,7}. Imagine it has been rotated at 5.

public class searchAfterRotated {
    int pivotSearch(int arr[],int n,int key){
        int pivot= findPivot(arr,0,n-1);
        if(pivot==-1)
            return binarySearch(arr,0,n-1,key);
        if(pivot==key)
            return pivot;
        if(key>=arr[0])
            /*
            If key>=0 means definitely the key has to be in left array as all elements after 0th element till pivot point
            will be greater than 0th element else key<=0 it would be in right array

            return binarySearch( arr,0,pivot-1,key);
        return binarySearch(arr,pivot+1,n-1,key);

    }
    int findPivot(int arr[],int low,int high){
        if(high<low)
            return -1;
        if(high==low)
            return low;
        int mid=(low+high)/2;
        if(mid>low & arr[mid]>arr[mid+1])
            return mid;
        if (mid<high & arr[mid-1] > arr[mid])
            return mid-1;
        if(arr[low]>=arr[high])         //array rotated
            return findPivot(arr,low,mid-1);
        return findPivot(arr,mid+1,high);
    }
    int binarySearch(int arr[],int low,int high,int key){
        if (high<=low)
            return -1;
        int mid=(low+high)/2;
        if (arr[mid]==key)
            return mid;
        if(arr[mid]<=key)
            return binarySearch(arr,mid+1,high,key);
        return binarySearch(arr,low,mid-1,key);
    }
    public static void main(String[] args){
        int array[]={3,4,5,6,7,1,2};
        searchAfterRotated sAR=new searchAfterRotated();
        System.out.println(sAR.pivotSearch(array,array.length,5));
    }
}
*/
/* Java program to search an element
   in a sorted and pivoted array*/

class searchAfterRotated
{

    /* Searches an element key in a
       pivoted sorted array arrp[]
       of size n */
    static int pivotedBinarySearch(int arr[], int n, int key)
    {
        int pivot = findPivot(arr, 0, n-1);

        // If we didn't find a pivot, then
        // array is not rotated at all
        if (pivot == -1)
            return binarySearch(arr, 0, n-1, key);

        // If we found a pivot, then first
        // compare with pivot and then
        // search in two subarrays around pivot
        if (arr[pivot] == key)
            return pivot;
        if (arr[0] <= key)
            return binarySearch(arr, 0, pivot-1, key);
        return binarySearch(arr, pivot+1, n-1, key);
    }

    /* Function to get pivot. For array
       3, 4, 5, 6, 1, 2 it returns
       3 (index of 6) */
    static int findPivot(int arr[], int low, int high)
    {
        // base cases
        if (high < low)
            return -1;
        if (high == low)
            return low;

       /* low + (high - low)/2; */
        int mid = (low + high)/2;
        if (mid < high && arr[mid] > arr[mid + 1])
            return mid;
        if (mid > low && arr[mid] < arr[mid - 1])
            return (mid-1);
        if (arr[low] >= arr[mid])
            return findPivot(arr, low, mid-1);
        return findPivot(arr, mid + 1, high);
    }

    /* Standard Binary Search function */
    static int binarySearch(int arr[], int low, int high, int key)
    {
        if (high < low)
            return -1;

       /* low + (high - low)/2; */
        int mid = (low + high)/2;
        if (key == arr[mid])
            return mid;
        if (key > arr[mid])
            return binarySearch(arr, (mid + 1), high, key);
        return binarySearch(arr, low, (mid -1), key);
    }

    // main function
    public static void main(String args[])
    {
        // Let us search 3 in below array
        int arr1[] = {5, 6, 7, 8, 9, 10, 1, 2, 3};
        int n = arr1.length;
        int key = 3;
        System.out.println("Index of the element is: "
                + pivotedBinarySearch(arr1, n, key));
    }
}