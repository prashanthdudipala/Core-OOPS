/**
 * Created by prashanth on 9/27/17.
 */
import java.util.Scanner;
public class arrayInsertionDeletion {
    int noOfElements;
    int array[] = new int[noOfElements];
    public static void createArray(int array[],int noOfElements){
        Scanner sc=new Scanner(System.in);
        for (int i = 0; i < noOfElements; i++) {
            array[i] = sc.nextInt();
        }
        for (int i = 0; i < array.length; i++) {
            System.out.print(array[i] + " ");
        }
    }
    public static int searchElement(int array[],int noOfElements,int elementToBeSearched){
        for(int i=0;i<noOfElements;i++){
            if(array[i]==elementToBeSearched){
                return i;
            }
        }
        return -1;
    }
    public static void deleteElement(int array[],int noOfElements,int key){
        int pos=searchElement(array[],noOfElements,key);
        if(pos==-1){
            System.out.println("Element not found");
        }
        for(int i=pos;i<noOfElements;i++){
            array[i]=array[i+1];
        }
        System.out.print("Element deleted and the array after deletion is:");
        for (int i = 0; i < array.length; i++) {
            System.out.print(array[i] + " ");
        }
    }
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the size of the array:");
        int n=sc.nextInt();
        int a[]=new int[n];
        createArray(a[],n);
        int elementToSearch=sc.nextInt();
        searchElement(a[],n,elementToSearch);
        int elementToBeDeleted=sc.nextInt();
        deleteElement(a[],n,elementToBeDeleted);
    }
}
