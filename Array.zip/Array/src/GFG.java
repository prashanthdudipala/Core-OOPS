/**
 * Created by prashanth on 10/6/17.
 */

import java.util.Scanner;
import java.lang.String;

    class GFG {
        int n;
        int arr[]=new int[n];
        private static void createArray(int arr[],int n){
            Scanner sc=new Scanner(System.in);
            for(int i=0;i<n;i++){
                    arr[i] = sc.nextInt();
            }
        }
        private static int sumArray(int arr[],int n){
            int sum=0;
            for(int i=0;i<n;i++){
                sum=arr[i]+sum;
            }
            return sum;
        }
        private static float avgArray(int arr[],int n){
            float avrg=0;
            int s= sumArray(arr,n);
            avrg=s/n;
            return avrg;
        }
        public static void main(String[] args){
            Scanner sc=new Scanner(System.in);
            int noOfTestCases=sc.nextInt();
            while(noOfTestCases>0){
                int sizeArray=sc.nextInt();
                int array[]=new int[sizeArray];
                if (sizeArray==0){
                    System.out.println("Enter the elements to get the sum and average of array elements!");
                    return;
                }
                else {
                    createArray(array, sizeArray);
                    noOfTestCases--;
                }
                System.out.print(sumArray(array, sizeArray));
                System.out.println(" " + avgArray(array, sizeArray));
            }
        }
    }

