import java.util.Scanner;

/**
 * Created by prashanth on 10/11/17.
 */
public class findingSumPair {
    private void sumPair(int arr[],int sum) {

        for (int i = 0; i < arr.length; i++)
            for (int j = 0; j != i & j < arr.length; j++)
                if (arr[i] + arr[j] == sum)
                    System.out.println("("+arr[i]+","+arr[j]+")");
        //else System.out.println("Not Found");
    }
    public static void main(String[] args){
        findingSumPair fsp=new findingSumPair();
        Scanner sc=new Scanner(System.in);
        int noOfElements=sc.nextInt();
        int array[]=new int[noOfElements];
        for(int i=0;i<noOfElements;i++){
            array[i]=sc.nextInt();
        }
        int sumRequired=sc.nextInt();
        fsp.sumPair(array,sumRequired);
    }
}
