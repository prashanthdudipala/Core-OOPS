/**
 * Created by prashanth on 9/25/17.
 */
public class binarySearch {
    int x;
    int n;
    int arr[]=new int[n];
    int y;
    int z;
    int mid;
    int start;
    int end;
        int search(int arr[],int x,int n) {
            while (start <= end) {
                mid = Math.floorDiv(n, 2);
                if (arr[mid] == x) {
                    return mid;
                } else if (x < arr[mid]) {
                    start = arr[0];
                    end = arr[mid-1];
                }
                else {
                    start=arr[mid+1];
                    end=arr[n];
                }
                return 1;
            }
            return -1;
        }
    boolean insert(int arr[], int y,int n)
    {
        if (y==search(arr,y,n)){
            return false;
        }
        else {
            int i;
            int k;
            for(i=n-1;i<0;i--){
                arr[i+1]=arr[i];
                if(arr[i] <y){
                    arr[i+1]=y;
                }
            }
            return true;
        }
    }
    boolean deleteEle(int arr[], int z,int n)
    {
        int delElement = search(arr,z,n);
        for(int i=delElement;i<n;i++){
            arr[i]=arr[i+1];
        }
        return 1;
    }
}
