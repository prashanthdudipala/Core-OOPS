import java.util.Scanner;

/**
 * Created by prashanth on 9/25/17.
 */
public class arrayTrialsV1 {
    int noOfElements;
    int array[] = new int[noOfElements];
    public static void createArray(int array[],int noOfElements){
        for (int i = 0; i < noOfElements; i++) {
            array[i] = sc.nextInt();
        }
        for (int i = 0; i < array.length; i++) {
            System.out.print(array[i] + " ");
        }
    }
        public static int searchElement(int array[],int noOfElements,int elementToBeSearched){
            for(int i=0;i<noOfElements;i++){
                if(array[i]==elementToBeSearched){
                    return i;
                }
                return -1;
            }
        }
        public static void deleteElement(int array[],int noOfElements,int key){
            int pos=searchElement(array[],noOfElements,key);
            if(pos==-1){
                System.out.println("Element not found");
            }
            for(i=pos;i<n;i++){
                array[i]=array[i+1];
            }
            System.out.print("Element deleted and the array after deletion is:");
            for (i = 0; i < array.length; i++) {
                System.out.print(array[i] + " ");
            }
        }
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        n=sc.nextInt("Enter the size of the array:");
        int a[]=new int[n];
        createArray(a[],n);
        elementToSearch=sc.nextInt();
        searchElement(a[],n,elementToSearch);
        elementToBeDeleted=sc.nextInt();
        deleteElement(a[],n,elementToBeDeleted);
}
}
