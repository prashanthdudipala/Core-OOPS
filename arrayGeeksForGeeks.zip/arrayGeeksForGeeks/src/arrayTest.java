import java.util.Scanner;

/**
 * Created by prashanth on 9/25/17.
 */
public class arrayTest {
    Scanner sc = new Scanner(System.in);
    int noOfElements;
    int array[];

    public static void createArray(int array[], int noOfElements) {
        Scanner scInner = new Scanner(System.in);
        for (int i = 0; i < noOfElements; i++) {
            array[i] = scInner.nextInt();
        }
        for (int i = 0; i < array.length; i++) {
            System.out.print(array[i] + " ");
        }
    }

    int searchElement;

    public static int searchable(int array[], int searchElement) {
        for (int i = 0; i <= array.length; i++) {
            if (array[i] == searchElement) {
                return i;
            }
        }
        return -1;
    }

    int insertElement;
    int insertKey;

    public static int insertionElement(int array[], int insertElement, int insertKey) {
       int n= array.length;
        array[n+1] = insertElement;
        if(array[n]==insertElement){
            return 1;
        }
        return 0;
    }
    public static int deleteElement(int array[],int deleteElement){
        int pos=searchable(array,deleteElement);
        boolean check;
        check= false;
        for(int i=pos;i<array.length-1;i++){
            array[i]=array[i+1];
        }
        if(searchable(array,deleteElement)<0){
            check=true;
            return 1;
        }
        return -1;
    }

        public static void main(String[] args){
            Scanner sc = new Scanner(System.in);
            int NoOfTestCases = sc.nextInt();
            int numbOfElements = sc.nextInt();
            int arr[] = new int[numbOfElements];
            createArray(arr,numbOfElements);
            int searchElem = sc.nextInt();
            searchable(arr,searchElem);
            int insKey= sc.nextInt();
            int insElement=sc.nextInt();
            insertionElement(arr,insElement,insKey);
            int delElement=sc.nextInt();
            deleteElement(arr,delElement);
        }

}
