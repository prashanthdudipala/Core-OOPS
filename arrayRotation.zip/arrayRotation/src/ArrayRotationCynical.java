import java.util.Arrays;

/**
 * Created by prashanth on 10/8/17.
 Given an array, cyclically rotate an array by one.

 Input:
 The first line of input contains an integer T denoting the number of test cases. Then T test cases follow.
 Each test case contains an integer n denoting the size of the array. Then following line contains 'n' integers forming the array.

 Output:
 Output the cyclically rotated array by one.
 */
public class ArrayRotationCynical {
    //int n;
    //int arr[]=new int[n];
    static int arr[] = new int[]{1, 2, 3, 4, 5};

    // Method for rotation
    static void rotate()
    {
        int x = arr[arr.length-1], i;
        for (i = arr.length-1; i > 0; i--)
            arr[i] = arr[i-1];
        arr[0] = x;
    }

    /* Driver program */
    public static void main(String[] args)
    {
        System.out.println("Given Array is");
        System.out.println(Arrays.toString(arr));

        rotate();

        System.out.println("Rotated Array is");
        System.out.println(Arrays.toString(arr));
    }
}