/**
 * Created by prashanth on 10/8/17.
 */
import java.io.IOException;
import java.util.Scanner;
public class GFG {
    int n;//No of elements in array
    int arr[]=new int[n];
    private static void rotateArray(int arr[],int d,int n){
        reverse(arr,0,d-1);
        reverse(arr,d+1-1,n-1);
        reverse(arr,0,n-1);
    }
    private static void printArray(int arr[],int n){
        for(int i=0;i<n;i++){
            System.out.print(arr[i]+" ");
        }
    }
    private static void reverse(int arr[],int start,int end){
        int temp;
        while(start<end){
            temp=arr[start];
            arr[start]=arr[end];
            arr[end]=temp;
            start++;
            end--;
        }
    }
    public static void main (String[] args) throws IOException {
        Scanner sc=new Scanner(System.in);
        int noOfTestCases=sc.nextInt();
        for(int i=0;i<noOfTestCases;i++){
        int noOfArrayElements=sc.nextInt();
        int array[]=new int[noOfArrayElements];
        for(i=0;i<noOfArrayElements;i++){
                array[i]=sc.nextInt();
            }
        int division=sc.nextInt();
        rotateArray(array,division,noOfArrayElements);
        printArray(array,noOfArrayElements);
        }
    }
}
