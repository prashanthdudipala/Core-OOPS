/**
 * Created by prashanth on 10/14/17.
 Problem: Swapping the nodes: say input is 1->2->3->4->5->6 and given to swap x=2,y=6 output:1->6->3->4->5->2
 Solution:There are four possible outcomes
 1)if x and y are same value then it returns nothing
 2)either of x or y may not be present so it returns nothing
 3)either of x or y might be the heads of the list
 4)x and y might be the adjacent elements
 */
public class linkedListSwap {
    Node head;
    static class Node{
        int data;
        Node next;
        Node(int d){
            data=d;
            next=null;
        }
    }
    //Forward pushing of elements
    public void push(int d){
        Node new_node=new Node(d);
        new_node.next=head;
        head=new_node;

    }
    public void swapNodes(int x,int y){
        /*Node tempx=head;
        Node tempy=head;
        Node prevx=null;
        Node prevy=null;
        Node temp;
        if (x==y){
            System.out.println("Swapping single element doesnt change much!");
            return;
        }
        //Search till x is found
        while (tempx !=null && tempx.data!=x){
        prevx=tempx;
        tempx=tempx.next;
        }
        //Search till y is found
        while (tempy!=null && tempy.data !=y){
            prevy=tempy;
            prevy=prevy.next;
        }
        //If either of nodes is not found
        if (tempx==null || tempy==null){
            return;
        }
        //If either of nodes is head
        if (prevx != null)
            prevx.next=tempy;   //if its not head then swap previous node address with y node
        else
            tempx=tempy;   //If x is head then swap y with head
        if (prevy !=null)
            prevy.next=tempx;   //if its not head then swap previous node address with x node
        else
            tempy=tempx;   //If y is head then swap x with head

        //if adjacent elements
        temp=tempx.next;
        tempx.next=tempy.next;
        tempy.next=temp;*/
        // Nothing to do if x and y are same
        if (x == y) return;

        // Search for x (keep track of prevX and CurrX)
        Node prevX = null, currX = head;
        while (currX != null && currX.data != x)
        {
            prevX = currX;
            currX = currX.next;
        }

        // Search for y (keep track of prevY and currY)
        Node prevY = null, currY = head;
        while (currY != null && currY.data != y)
        {
            prevY = currY;
            currY = currY.next;
        }

        // If either x or y is not present, nothing to do
        if (currX == null || currY == null)
            return;

        // If x is not head of linked list
        if (prevX != null)
            prevX.next = currY;
        else //make y the new head
            head = currY;

        // If y is not head of linked list
        if (prevY != null)
            prevY.next = currX;
        else // make x the new head
            head = currX;

        // Swap next pointers
        Node temp = currX.next;
        currX.next = currY.next;
        currY.next = temp;
    }

    public void printList(){
        Node n=head;
        while (n!=null){
            System.out.print(n.data+" ");
            n=n.next;
        }
    }
    public static void main(String[] args){
        linkedListSwap lls=new linkedListSwap();
        lls.push(2);
        lls.push(4);
        lls.push(6);
        lls.push(8);
        lls.push(10);
        lls.push(12);
        lls.push(14);
        lls.push(16);
        lls.push(18);
        lls.push(20);
        lls.printList();
        lls.swapNodes(8,18);
        System.out.println("After Swapping the nodes");
        lls.printList();
    }
}
