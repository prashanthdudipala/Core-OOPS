/**
 * Created by prashanth on 10/14/17.
 */
public class linkedListNthNode {
    Node head;
    static class Node{
        int data;
        Node next;
        Node(int d){
            data=d;
            next=null;
        }
    }
    public void push(int d){
        Node new_node=new Node(d);
        new_node.next=head;
        head=new_node;
    }
    public void printList(){
        Node n=head;
        while (n!=null){
            System.out.print(n.data+" ");
            n=n.next;
        }
    }
    private void findIndex(int key){
        Node curr=head;
        int count=0;
        while (curr !=null && curr.data!=key){
            curr=curr.next;
            count++;
        }
        System.out.println("The index of "+key+":"+count);
    }
    public static void main(String[] args){
        linkedListNthNode llnn=new linkedListNthNode();
        llnn.push(2);
        llnn.push(4);
        llnn.push(6);
        llnn.push(8);
        llnn.push(10);
        llnn.printList();
        llnn.findIndex(10);
    }
}
