/**
 * Created by prashanth on 10/14/17.
 * Creation of linked list
 * Types of Insertion of elements in linked list
 * Printing the linked list
 */
public class linkedLists {
    Node head;
    //Has to be declared static for main class to access it
    static class Node{
        int data;
        Node next;
        Node(int d){
            data=d;
            next=null;
        }
        }
    // Traversing the list : way of printing the linked list outside the main method
        /*public void printList(){
        Node n=head;
        while ((n != null)){
            System.out.println(n.data);
            n=n.next;
        }
    }*/
        /////////////

    //Inserting node at the front of the list(As head)
    public void insertNode(int new_data){
        Node new_node=new Node(new_data);
        new_node.next=head;
        head=new_node;
    }
    //Inserting node in the middle of the list
    public void insertMiddle(Node prev_node,Node next_node,int new_data){
        if(prev_node==null) {
            System.out.println("Previous node Cannot be null");
            return;
        }
        Node new_node= new Node(new_data);
        prev_node.next=new_node;
        new_node.next=next_node;
    }
    //Inserting node After give node of the list
    public void insertAfter(Node prev_node,int new_data){
        if(prev_node==null) {
            System.out.println("Previous node Cannot be null");
            return;
        }
        Node new_node= new Node(new_data);
        prev_node.next=new_node.next;
        prev_node.next=new_node;
    }
    //Inserting node at the tail of the list
    public void insertLast(int new_data){
        Node last_node=new Node(new_data);
        Node n=head;
        if(n==null){
            head=new Node(new_data);
        }
        last_node.next=null;
        while (n.next!=null)
            n=n.next;
        n.next=last_node;
        return;
    }
    public static void main(String[] args){
        linkedLists llists=new linkedLists();
        llists.head=new Node(1);
        Node secondElement=new Node(2);
        Node thirdElement=new Node(3);
        Node fourthEleement=new Node(4);
        llists.head.next=secondElement;
        secondElement.next=thirdElement;
        thirdElement.next=fourthEleement;
        //Say we are inserting between third and fourth elements
        llists.insertMiddle(thirdElement,fourthEleement,5);
        //Say we are inserting after fourth element
        llists.insertAfter(fourthEleement,6);//here fourthelement is 4 because we assigned 4 to fourthelement.
        //Adding at the tail of the list
        llists.insertLast(10);
        //Traversing the list within the main method
        Node n=llists.head;
        while ((n != null)){
            System.out.println(n.data);
            n=n.next;
        }
        //llists.printList();
    }
}
