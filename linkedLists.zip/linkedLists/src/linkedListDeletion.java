/**
 * Created by prashanth on 10/14/17.
 * Linked list creation
 * forward pushing of elements in linked list
 * Types of Deletion of elements in linked list
 * Computing the size of linked list
 * Printing the linked list
 */
public class linkedListDeletion {
    Node head;
    static class Node{
        int data;
        Node next;
        Node(int d){
            data=d;
            next=null;
        }
    }
    //Adding the nodes at front of the list
    public void insertNode(int data){
        Node new_node=new Node(data);
        new_node.next=head;
        head=new_node;
    }
    //Deleting the node once it finds the key data value
    public void deleteNode(int key){
        //store head node
        Node temp=head, prev=null;
        //if head itself store the key element
        if(temp != null && temp.data==key){
            head = temp.next;
        }
        //keep track of the previous node as we change it to temp.next
        while (temp != null && temp.data != key){
            prev=temp; //just keep traversing till you find the key
            temp=temp.next; // once you find it break out of the loop
        }
        if (temp==null){
            return; // After breaking out if you not find the key just return
        }
        prev.next=temp.next; //If you found out one then just overwrite the address.
    }
    //Deleting the node with given position
    public void deleteNodeusingPosition(int position){
        Node tnode=head;
        if(tnode==null)
            return;
        if(position==0){
            head=tnode.next;
            return;
        }
        for(int i=0;i<position-1;i++)
            tnode=tnode.next;
        if(tnode==null || tnode.next==null)
            return;
        Node forward=tnode.next.next;
        tnode.next=forward;
    }
    //Printing the list
    public void printList(){
        int count=0;
        Node n=head;
        while (n!=null){
            System.out.print(n.data+" ");
            n=n.next;
            count++;
        }
        System.out.println(count);
    }


    public static void main(String[] args){
        linkedListDeletion lld=new linkedListDeletion();
        lld.insertNode(2);
        lld.insertNode(4);
        lld.insertNode(6);
        lld.insertNode(8);
        lld.insertNode(9);
        lld.insertNode(10);
        lld.insertNode(12);
        lld.insertNode(13);
        lld.insertNode(14);
        lld.insertNode(17);
        lld.insertNode(18);
        System.out.println("Before Deleting");
        lld.printList();
        System.out.println("After Deleting the node using key value");
        lld.deleteNode(9);
        System.out.println("After Deleting the node using position of the node");
        lld.deleteNodeusingPosition(8);
        lld.printList();
    }
}
