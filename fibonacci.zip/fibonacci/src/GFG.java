/**
 * Created by prashanth on 9/29/17.
 */
import java.util.Scanner;

public class GFG {

    private static void fib(long n){
        long a=0;
        long b=1;
        long c;
        if(n==0||n==1){
            System.out.println(+n);
        }
        else{
            for(int i=2;i<=n;i++){
                c=(a+b)%1000000007;
                a=b;
                b=c;
            }
            System.out.println(b);
        }
    }
    public static void main (String[] args) {
        Scanner sc=new Scanner(System.in);
        int noOfTestCases= sc.nextInt();
        if(noOfTestCases==0){
            System.out.println("No output");
        }
        else{
            for(int i=1;i<=noOfTestCases;i++){
                int fibonacciNumber=sc.nextInt();
                fib(fibonacciNumber);
            }
        }
    }
}
