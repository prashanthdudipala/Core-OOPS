/**
 * Created by prashanth on 10/5/17.
 */
import java.util.Scanner;
public class binarySearch {
    int n;
    int arr[]=new int[n];
    int key;
    static int search(int arr[], int key){
        int len= arr.length;
        int start=arr[0];
        int end=arr[len-1];
        int mid=len/2;
        if(mid==key) {
            return mid;
        }
            if(mid<key) {
                start = arr[0];
                end = arr[mid];
                return search(arr,key);
            }
            if (mid>key){
            start= mid+1;
            end= len-1;
            return search(arr,key);
            }
            return -1;
        }
    public static void main(String[] args){
        Scanner sc= new Scanner(System.in);
        //int size=sc.nextInt();
        int a[]={12,16,23,56,58,60,74,83,96,99};
        binarySearch bs=new binarySearch();
        bs.search(a,60);
    }
}

