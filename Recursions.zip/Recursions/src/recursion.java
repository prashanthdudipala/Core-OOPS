/**
 * Created by prashanth on 10/4/17.
 */
public class recursion {
    void fun1(int n) {
        int i = 0;
        if (n >1)

        {
            fun1(n - 1);
        }
        for (i = 0; i < n; i++)
            System.out.println("*");
    }
    public static void main(String[] args){
        recursion re=new recursion();
        re.fun1(5);
    }
}
